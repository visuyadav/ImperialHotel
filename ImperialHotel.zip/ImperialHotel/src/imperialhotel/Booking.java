/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imperialhotel;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Visu
 */
@Entity
@Table(name = "booking", catalog = "imperial_hotel", schema = "")
@NamedQueries({
    @NamedQuery(name = "Booking.findAll", query = "SELECT b FROM Booking b")
    , @NamedQuery(name = "Booking.findBySno", query = "SELECT b FROM Booking b WHERE b.sno = :sno")
    , @NamedQuery(name = "Booking.findByUsername", query = "SELECT b FROM Booking b WHERE b.username = :username")
    , @NamedQuery(name = "Booking.findByNoperson", query = "SELECT b FROM Booking b WHERE b.noperson = :noperson")
    , @NamedQuery(name = "Booking.findByBookingNo", query = "SELECT b FROM Booking b WHERE b.bookingNo = :bookingNo")
    , @NamedQuery(name = "Booking.findByRoomNo", query = "SELECT b FROM Booking b WHERE b.roomNo = :roomNo")
    , @NamedQuery(name = "Booking.findByChargesDay", query = "SELECT b FROM Booking b WHERE b.chargesDay = :chargesDay")
    , @NamedQuery(name = "Booking.findByAdvance", query = "SELECT b FROM Booking b WHERE b.advance = :advance")
    , @NamedQuery(name = "Booking.findByTotal", query = "SELECT b FROM Booking b WHERE b.total = :total")})
public class Booking implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Column(name = "SNO")
    private Integer sno;
    @Id
    @Basic(optional = false)
    @Column(name = "username")
    private String username;
    @Column(name = "Noperson")
    private Integer noperson;
    @Column(name = "BookingNo")
    private Integer bookingNo;
    @Column(name = "RoomNo")
    private Integer roomNo;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "ChargesDay")
    private BigDecimal chargesDay;
    @Column(name = "Advance")
    private Long advance;
    @Column(name = "Total")
    private BigDecimal total;

    public Booking() {
    }

    public Booking(String username) {
        this.username = username;
    }

    public Integer getSno() {
        return sno;
    }

    public void setSno(Integer sno) {
        Integer oldSno = this.sno;
        this.sno = sno;
        changeSupport.firePropertyChange("sno", oldSno, sno);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        String oldUsername = this.username;
        this.username = username;
        changeSupport.firePropertyChange("username", oldUsername, username);
    }

    public Integer getNoperson() {
        return noperson;
    }

    public void setNoperson(Integer noperson) {
        Integer oldNoperson = this.noperson;
        this.noperson = noperson;
        changeSupport.firePropertyChange("noperson", oldNoperson, noperson);
    }

    public Integer getBookingNo() {
        return bookingNo;
    }

    public void setBookingNo(Integer bookingNo) {
        Integer oldBookingNo = this.bookingNo;
        this.bookingNo = bookingNo;
        changeSupport.firePropertyChange("bookingNo", oldBookingNo, bookingNo);
    }

    public Integer getRoomNo() {
        return roomNo;
    }

    public void setRoomNo(Integer roomNo) {
        Integer oldRoomNo = this.roomNo;
        this.roomNo = roomNo;
        changeSupport.firePropertyChange("roomNo", oldRoomNo, roomNo);
    }

    public BigDecimal getChargesDay() {
        return chargesDay;
    }

    public void setChargesDay(BigDecimal chargesDay) {
        BigDecimal oldChargesDay = this.chargesDay;
        this.chargesDay = chargesDay;
        changeSupport.firePropertyChange("chargesDay", oldChargesDay, chargesDay);
    }

    public Long getAdvance() {
        return advance;
    }

    public void setAdvance(Long advance) {
        Long oldAdvance = this.advance;
        this.advance = advance;
        changeSupport.firePropertyChange("advance", oldAdvance, advance);
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        BigDecimal oldTotal = this.total;
        this.total = total;
        changeSupport.firePropertyChange("total", oldTotal, total);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (username != null ? username.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Booking)) {
            return false;
        }
        Booking other = (Booking) object;
        if ((this.username == null && other.username != null) || (this.username != null && !this.username.equals(other.username))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "imperialhotel.Booking[ username=" + username + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
